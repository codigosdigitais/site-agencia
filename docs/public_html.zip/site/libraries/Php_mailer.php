<?php if( ! defined('BASEPATH')) exit('No direct script access allowed');

require("php_mailer/class.phpmailer.php");

class Php_mailer extends PHPMailer {

}