<?php

class Model_conteudo extends MY_Model {


}
