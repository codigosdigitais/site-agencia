<?php

class Model_inicial extends MY_Model {

	function __construct(){
		parent::__construct();			
	}

}