<?php /* @var $this CI_Controller */ ?>







<section class="conteudo_erro">



    <div class="erro_cont left">



        <a href="<?php echo base_url(); ?>" title="Voltar para o site" class="img_404 left">



            <img src="<?php echo base_url("site/modules/inicial/images_404/404.png"); ?>" />            



        </a>



        <img src="<?php echo base_url("site/modules/inicial/images_404/texto_erro.png"); ?>" class="texto_erro" />



        <a href="<?php echo base_url(); ?>" title="Voltar para o site" class="bt_erro left"></a>



    </div>



</section>















