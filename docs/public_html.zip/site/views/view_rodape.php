    
        <footer class="page-footer-full section section-full-width">
            <div class="shell">
                <div class="range range-15">
                    <div class="cell-sm-5">
                        <p class="copyright">Códigos Digitais | Muito mais que uma agência digital, somos a solução completa para o seu negócio. &#169; 2002-<span class="copyright-year"></span>. 
                        </p>
                    </div>
                    <div class="cell-sm-5 text-sm-right">

                    </div>
                </div>
            </div>
        </footer>
    </div>
    <!-- Global Mailform Output-->
    <div class="snackbars" id="form-output-global"></div>
    <!-- Javascript-->
    <script data-cfasync="false" src="<?php echo base_url('site/assets'); ?>/js/email-decode.min.js"></script>
    <script src="<?php echo base_url('site/assets'); ?>/js/core.min.js"></script>
    <script src="<?php echo base_url('site/assets'); ?>/js/script.js"></script>
    <!--
    <script type="text/javascript" src="https://cdn.pushassist.com/account/assets/psa-codigosdigitais.js" async></script>
    -->

    <script type="text/javascript">(function(n,r,l,d){try{var h=r.head||r.getElementsByTagName("head")[0],s=r.createElement("script");s.defer=true;s.setAttribute("type","text/javascript");s.setAttribute("src",l);n.neuroleadId=d;h.appendChild(s);}catch(e){}})(window,document,"https://cdn.leadster.com.br/neurolead/neurolead.min.js", 55703);</script>

    <!-- Google tag (gtag.js) -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=AW-11072504732"></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());
    
      gtag('config', 'AW-11072504732');
    </script>
    
        <!-- Google tag (gtag.js) -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-K9QWK5VG51"></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());
    
      gtag('config', 'G-K9QWK5VG51');
    </script>
</body>

</html>